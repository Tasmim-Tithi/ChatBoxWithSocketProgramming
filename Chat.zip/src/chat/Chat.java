
package chat;

/**
 *
 * @author Tasmim
 */
public class Chat {   
    public static void main(String[] args) {
    }
    
}
